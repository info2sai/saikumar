let num1=10
let num2=35
if (num1>num2) {
console.log("greatest no is "+num1);
} else {
    console.log("greatest no is "+num2);
}