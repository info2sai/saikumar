let num1=5
let num2=35
if (num1<num2) {
console.log("Least no is "+num1);
} else {
    console.log("Least no is "+num2);
}