let num=1
if (num>=0) {
    console.log("Number is positive");
} else {
    console.log("Number is negative");  
}