let num= 5
if (num%2==0) {
    console.log("its an even number"); 
} else {
    console.log("its an odd number");   
}