let num=36
if (num%3==0) {
console.log("Number is multiple of 3");
    
} else {
    console.log("Number is not multiple of 3");
}