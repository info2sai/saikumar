let num=1004
var ones=Math.floor(num/1%10)
if (ones==4) {
    console.log("the given number has 4 at unit's place");
    
} else {
    console.log("the given number doesn't have 4 at unit's place");
}