let num1=6
let num2=35
let num3=55
if (num1<num2&&num1<num3) {
    console.log("Least no is "+num1);
} else if (num2<num3&&num2<num1) {
    console.log("Least no is "+num2);
} else {
    console.log("Least no is "+num3);
} 
