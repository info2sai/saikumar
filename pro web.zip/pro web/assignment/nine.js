let num1=156
let num2=35
let num3=55
if (num1>num2&&num1>num3) {
    console.log("Greatest no is "+num1);
} else if (num2>num3&&num2>num1) {
    console.log("Greatest no is "+num2);
} else {
    console.log("Greatest no is "+num3);
} 
