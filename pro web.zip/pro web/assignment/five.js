let num=444
if (num>99&&num<1000) {
    console.log("its a three digit"); 
} else {
    console.log("its not a three digit"); 
}