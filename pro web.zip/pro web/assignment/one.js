let num=28
if (num%7==0) {
console.log("Number is divisble by 7");
    
} else {
    console.log("Number is not divisble by 7");
}