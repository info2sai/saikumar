for()
{
    console.log("HELLO WORLD");
}