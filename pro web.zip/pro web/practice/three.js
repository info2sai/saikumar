let salary=50000;
if(salary>=55000){
    console.log("eligible");
}
else{
    console.log("not eligible");
}