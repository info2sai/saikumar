let Salary=55000
Salary>=50000 ? console.log("eligible") : console.log("not eligible");