let i=1
console.log('The factors of 24 are : ');
while (i<=100) {
    if (24%i==0) {
        console.log(i);
    } 
    i=i+1
}