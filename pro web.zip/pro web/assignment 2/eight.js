let i=1
console.log("multiples of 4 are ");
while (i<=10) {
console.log(4*i);
    i=i+1
}