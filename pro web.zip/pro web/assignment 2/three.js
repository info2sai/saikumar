for (let i=5;i<=15;i++ ){
    console.log(i);
}