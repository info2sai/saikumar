for (let i=15;i>=10;i--){
    console.log(i);
}
