let i=1
while (i<=10) {
    console.log(4*i);
    i=i+1
}