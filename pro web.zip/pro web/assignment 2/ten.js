let i=1
while (i<=100) {
    if (24%i==0) {
        console.log(i);
    } 
    i=i+1
}